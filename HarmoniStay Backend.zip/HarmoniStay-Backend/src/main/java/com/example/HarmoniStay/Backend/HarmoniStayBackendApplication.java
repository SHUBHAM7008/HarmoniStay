package com.example.HarmoniStay.Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HarmoniStayBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarmoniStayBackendApplication.class, args);
	}

}
