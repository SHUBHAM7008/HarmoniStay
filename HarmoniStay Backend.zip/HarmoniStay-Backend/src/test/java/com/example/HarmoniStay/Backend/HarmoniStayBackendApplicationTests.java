package com.example.HarmoniStay.Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarmoniStayBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
